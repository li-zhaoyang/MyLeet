import java.util.*;
class Solution {
  boolean[] marked;
  Stack<Integer> stack;
  boolean cycle;
    public int[] findOrder(int numCourses, int[][] prerequisites) {
      //TODO Input: 1 [] Output:[] Expected: [0]
      int[] ansNull = new int[0];
      if(numCourses == 0 || prerequisites == null)
        return ansNull;
      int[] ans = new int[numCourses];
      ArrayList<LinkedList<Integer>> vArray = new ArrayList<LinkedList<Integer>>();
      for (int i = 0; i < numCourses; i++) {
        vArray.add(new LinkedList<Integer>());
      }
      for (int[] pair: prerequisites) {
        LinkedList<Integer> ll = vArray.get(pair[0]);
        ll.add(pair[1]);
      }
      stack = new Stack<Integer>();
      marked = new boolean[numCourses];
      cycle = false;
      for (int i = 0; i < numCourses; i++) {
        if (marked[i]) continue;
        dfs(i, vArray, i);
        if (cycle == true)  return  ansNull;
      }
      for (int i = 0; i < numCourses; i++) {
        ans[numCourses - i - 1] = stack.pop();
      }
      return ans;
    }

    private void dfs(int v,ArrayList<LinkedList<Integer>> vArray, int root) {
      marked[v] = true;
      for (int w: vArray.get(v)) {
        if (w == root) {
          cycle = true;
          return;
        }
        if (!marked[w]){
          dfs(w, vArray, root);
          if(cycle == true) return;
        }
      }
      stack.push(v);
    }
}
